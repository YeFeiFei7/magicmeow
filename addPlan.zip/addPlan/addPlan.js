document.addEventListener("DOMContentLoaded", function () {
    const illustration = document.querySelector(".illustration");
    const panels = {
        folder: {
            btn: document.getElementById("toggle-btn"),
            panel: document.querySelector(".folder"),
            close: document.getElementById("close-btn")
        },
        quadrants: {
            btn: document.getElementById("quadrants-btn"),
            panel: document.querySelector(".quadrants"),
            close: document.getElementById("closeq-btn")
        },
        time: {
            btn: document.getElementById("time-btn"),
            panel: document.querySelector(".time-picker-container"),
            close: document.getElementById("closet-btn")
        },
        reminder: {
            btn: document.getElementById("reminder-btn"),
            panel: document.querySelector(".reminder"),
            close: document.getElementById("closer-btn")
        },
        date: {
            btn: document.getElementById("date-btn"),
            panel: document.querySelector(".calendar-container"),
            close: document.getElementById("closed-btn")
        }
    };

    let currentOpenPanel = null;

    for (let key in panels) {
        const { btn, panel, close } = panels[key];

        btn.addEventListener("click", function () {
            // Не открываем, если уже открыта другая панель
            if (currentOpenPanel && currentOpenPanel !== panel) return;

            illustration.style.display = "none";
            panel.style.display = "block";
            close.style.display = "inline";
            currentOpenPanel = panel;
        });

        close.addEventListener("click", function () {
            panel.style.display = "none";
            illustration.style.display = "block";
            close.style.display = "none";
            currentOpenPanel = null;
        });
    }
});




let currentDate = dayjs();
let selectedStart = null;
let selectedEnd = null;

function renderCalendar() {
  const firstDayOfMonth = currentDate.startOf('month');
  const lastDayOfMonth = currentDate.endOf('month');
  const daysInMonth = lastDayOfMonth.date();
  const firstDayWeekday = (firstDayOfMonth.day() + 6) % 7; // Понедельник = 0

  document.getElementById('month-year').textContent = currentDate.format('YYYY MMMM');
  const calendarBody = document.getElementById('calendar-body');
  calendarBody.innerHTML = '';

  let row = document.createElement('tr');

  for (let i = 0; i < firstDayWeekday; i++) {
    row.appendChild(document.createElement('td'));
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const cell = document.createElement('td');
    cell.textContent = day;
    const cellDate = currentDate.date(day);

    const isSameAsStart = selectedStart && cellDate.isSame(selectedStart, 'day');
    const isSameAsEnd = selectedEnd && cellDate.isSame(selectedEnd, 'day');
    const isInRange = selectedStart && selectedEnd &&
                      cellDate.isAfter(selectedStart, 'day') && cellDate.isBefore(selectedEnd, 'day');

    if (isSameAsStart && !selectedEnd) {
      cell.classList.add('single-selection');
    } else if (isSameAsStart || isSameAsEnd) {
      cell.classList.add('range-endpoints');
    } else if (isInRange) {
      cell.classList.add('range-date');
    }

    cell.addEventListener('click', () => handleDateClick(cellDate));
    row.appendChild(cell);

    if ((row.children.length) % 7 === 0) {
      calendarBody.appendChild(row);
      row = document.createElement('tr');
    }
  }

  if (row.children.length > 0) {
    calendarBody.appendChild(row);
  }
}

function handleDateClick(date) {
  if (selectedStart && !selectedEnd && date.isSame(selectedStart, 'day')) {
    selectedStart = null;
  } else if (!selectedStart || (selectedStart && selectedEnd)) {
    selectedStart = date;
    selectedEnd = null;
  } else if (date.isBefore(selectedStart)) {
    selectedEnd = selectedStart;
    selectedStart = date;
  } else {
    selectedEnd = date;
  }

  renderCalendar();
}

function changeMonth(offset) {
  currentDate = currentDate.add(offset, 'month');
  renderCalendar();
}

renderCalendar();