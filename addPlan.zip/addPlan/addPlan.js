//Sidebar
document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.querySelector(".sidebar");
  const toggleBtn = document.querySelector(".toggle-btn");
  const plusIcon = document.querySelector(".plus-icon");


  toggleBtn.addEventListener("click", function () {
    sidebar.classList.toggle("open");


    if (sidebar.classList.contains("open")) {
      plusIcon.style.display = "none";
    } else {
      plusIcon.style.display = "block";
    }
  });
});

// Detailed Configuration
document.addEventListener("DOMContentLoaded", function () {
  const illustration = document.querySelector(".illustration");

  const panels = {
    folder: {
      btn: document.getElementById("toggle-btn"),
      panel: document.querySelector(".folder"),
      close: document.getElementById("close-btn")
    },
    createFolder: {
      btn: document.getElementById("createFolder"),
      panel: document.querySelector(".create-folder"),
      close: document.getElementById("closec-btn")
    },
    quadrants: {
      btn: document.getElementById("quadrants-btn"),
      panel: document.querySelector(".quadrants"),
      close: document.getElementById("closeq-btn")
    },
    time: {
      btn: document.getElementById("time-btn"),
      panel: document.querySelector(".time-picker-container"),
      close: document.getElementById("closet-btn")
    },
    reminder: {
      btn: document.getElementById("reminder-btn"),
      panel: document.querySelector(".reminder"),
      close: document.getElementById("closer-btn")
    },
    date: {
      btn: document.getElementById("date-btn"),
      panel: document.querySelector(".calendar-container"),
      close: document.getElementById("closed-btn")
    }
  };

  let currentOpenPanel = null;

  function openOrClosePanel(panelObj) {
    const { panel, close } = panelObj;

    if (currentOpenPanel && currentOpenPanel !== panel) {

      currentOpenPanel.style.display = "none";
      for (let key in panels) {
        if (panels[key].panel === currentOpenPanel) {
          panels[key].close.style.display = "none";
        }
      }
    }

    if (currentOpenPanel === panel) {

      panel.style.display = "none";
      close.style.display = "none";
      if (illustration) illustration.style.display = "block";
      currentOpenPanel = null;
    } else {

      if (illustration) illustration.style.display = "none";
      panel.style.display = "block";
      close.style.display = "inline";
      currentOpenPanel = panel;
    }
  }

  for (let key in panels) {
    const { btn, panel, close } = panels[key];

    if (!btn || !panel || !close) continue;


    btn.addEventListener("click", () => openOrClosePanel(panels[key]));


    close.addEventListener("click", () => {
      panel.style.display = "none";
      close.style.display = "none";
      if (illustration) illustration.style.display = "block";
      currentOpenPanel = null;
    });


    panel.addEventListener("click", (event) => {
      if (event.target === panel) {
        openOrClosePanel(panels[key]);
      }
    });
  }
});


//Quadrant
const quadrantItems = document.querySelectorAll('.quadrant-item');
const oval = document.querySelector('.highlight-oval');

const colorMap = {
  'top-left': '#FED981',
  'top-right': '#EE7981',
  'bottom-left': '#AFD2BC',
  'bottom-right': '#B3B8F0'
};

quadrantItems.forEach(item => {
  item.addEventListener('click', () => {
    const rect = item.getBoundingClientRect();
    const parentRect = item.parentElement.getBoundingClientRect();


    let color = '#000';
    for (let key in colorMap) {
      if (item.classList.contains(key)) {
        color = colorMap[key];
        break;
      }
    }

    // styles
    oval.style.left = (rect.left - parentRect.left + rect.width / 2 - 90) + "px";
    oval.style.top = (rect.top - parentRect.top + 10) + "px";
    oval.style.borderColor = color;
    oval.style.display = "block";
  });
});


//calendar
let currentDate = dayjs();
let selectedStart = null;
let selectedEnd = null;

function renderCalendar() {
  const firstDayOfMonth = currentDate.startOf('month');
  const lastDayOfMonth = currentDate.endOf('month');
  const daysInMonth = lastDayOfMonth.date();
  const firstDayWeekday = (firstDayOfMonth.day() + 6) % 7; // monday = 0

  document.getElementById('month-year').textContent = currentDate.format('YYYY MMMM');
  const calendarBody = document.getElementById('calendar-body');
  calendarBody.innerHTML = '';

  let row = document.createElement('tr');

  for (let i = 0; i < firstDayWeekday; i++) {
    row.appendChild(document.createElement('td'));
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const cell = document.createElement('td');
    cell.textContent = day;
    const cellDate = currentDate.date(day);

    const isSameAsStart = selectedStart && cellDate.isSame(selectedStart, 'day');
    const isSameAsEnd = selectedEnd && cellDate.isSame(selectedEnd, 'day');
    const isInRange = selectedStart && selectedEnd &&
      cellDate.isAfter(selectedStart, 'day') && cellDate.isBefore(selectedEnd, 'day');

    if (isSameAsStart && !selectedEnd) {
      cell.classList.add('single-selection');
    } else if (isSameAsStart || isSameAsEnd) {
      cell.classList.add('range-endpoints');
    } else if (isInRange) {
      cell.classList.add('range-date');
    }

    cell.addEventListener('click', () => handleDateClick(cellDate));
    row.appendChild(cell);

    if ((row.children.length) % 7 === 0) {
      calendarBody.appendChild(row);
      row = document.createElement('tr');
    }
  }

  if (row.children.length > 0) {
    calendarBody.appendChild(row);
  }
}

function handleDateClick(date) {
  if (selectedStart && !selectedEnd && date.isSame(selectedStart, 'day')) {
    selectedStart = null;
  } else if (!selectedStart || (selectedStart && selectedEnd)) {
    selectedStart = date;
    selectedEnd = null;
  } else if (date.isBefore(selectedStart)) {
    selectedEnd = selectedStart;
    selectedStart = date;
  } else {
    selectedEnd = date;
  }

  renderCalendar();

  if (typeof markCalendarSelected === "function") {
    markCalendarSelected();
  }
}

function changeMonth(offset) {
  currentDate = currentDate.add(offset, 'month');
  renderCalendar();
}

renderCalendar();


// reminder

const buttons = document.querySelectorAll('.option-button');
const selects = {
  hours: document.getElementById('scroll-hours'),
  minutes: document.getElementById('scroll-minutes'),
  days: document.getElementById('scroll-days')
};

let currentType = 'hours';
let selectedValues = {
  hours: 0,
  minutes: 0,
  days: 0
};


buttons.forEach(btn => {
  btn.addEventListener('click', () => {
    buttons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    currentType = btn.getAttribute('data-type');

    Object.keys(selects).forEach(key => {
      selects[key].classList.add('hidden');
    });
    selects[currentType].classList.remove('hidden');
  });
});


Object.keys(selects).forEach(type => {
  const scroll = selects[type];
  const options = scroll.querySelectorAll('.scroll-option');
  let isScrolling = false;


  scroll.addEventListener('wheel', (e) => {
    e.preventDefault();
    if (isScrolling) return;

    isScrolling = true;
    const direction = e.deltaY > 0 ? 1 : -1;


    let currentIndex = [...options].findIndex(opt => opt.classList.contains('selected'));
    if (currentIndex === -1) currentIndex = 0;

    let nextIndex = Math.min(Math.max(currentIndex + direction, 0), options.length - 1);
    const nextOption = options[nextIndex];


    options.forEach(opt => opt.classList.remove('selected'));
    nextOption.classList.add('selected');
    nextOption.scrollIntoView({ behavior: 'smooth', block: 'center' });

    selectedValues[type] = nextOption.textContent.trim();
    console.log(`Selected ${type}: ${selectedValues[type]}`);

    setTimeout(() => {
      isScrolling = false;
    }, 300);
  }, { passive: false });


  scroll.addEventListener('scroll', () => {
    const center = scroll.getBoundingClientRect().top + scroll.clientHeight / 2;
    let closest = null;
    let minDiff = Infinity;

    options.forEach(opt => {
      const rect = opt.getBoundingClientRect();
      const diff = Math.abs(center - (rect.top + rect.height / 2));
      if (diff < minDiff) {
        minDiff = diff;
        closest = opt;
      }
    });

    if (closest) {
      options.forEach(opt => opt.classList.remove('selected'));
      closest.classList.add('selected');
      selectedValues[type] = closest.textContent.trim();
    }
  });
});


const reminderCheckbox = document.getElementById('reminder');
const reminderContent = document.querySelector('.reminder-hide');

reminderCheckbox.addEventListener('change', () => {
  if (reminderCheckbox.checked) {
    reminderContent.style.visibility = 'visible';
  } else {
    reminderContent.style.visibility = 'hidden';
  }
});

// time
function generateTimeOptions(containerId) {
  const container = document.getElementById(containerId);
  for (let h = 0; h < 24; h++) {
    for (let m = 0; m < 60; m += 5) {
      const time = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
      const div = document.createElement('div');
      div.className = 'time-option';
      div.textContent = time;
      container.appendChild(div);
    }
  }
}

['start-time-scroll', 'end-time-scroll'].forEach(id => {
  generateTimeOptions(id);

  const scroll = document.getElementById(id);
  const options = scroll.querySelectorAll('.time-option');
  let isScrolling = false;

  scroll.addEventListener('wheel', (e) => {
    e.preventDefault();
    if (isScrolling) return;
    isScrolling = true;
    const direction = e.deltaY > 0 ? 1 : -1;
    let currentIndex = [...options].findIndex(opt => opt.classList.contains('selected'));
    if (currentIndex === -1) currentIndex = 0;
    let nextIndex = Math.min(Math.max(currentIndex + direction, 0), options.length - 1);
    const next = options[nextIndex];
    options.forEach(opt => opt.classList.remove('selected'));
    next.classList.add('selected');
    next.scrollIntoView({ behavior: 'smooth', block: 'center' });
    setTimeout(() => isScrolling = false, 300);
  }, { passive: false });

  scroll.addEventListener('scroll', () => {
    const center = scroll.getBoundingClientRect().top + scroll.clientHeight / 2;
    let closest = null;
    let minDiff = Infinity;
    options.forEach(opt => {
      const rect = opt.getBoundingClientRect();
      const diff = Math.abs(center - (rect.top + rect.height / 2));
      if (diff < minDiff) {
        minDiff = diff;
        closest = opt;
      }
    });
    if (closest) {
      options.forEach(opt => opt.classList.remove('selected'));
      closest.classList.add('selected');
    }
  });
});