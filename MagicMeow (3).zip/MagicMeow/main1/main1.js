document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const addPlanButton = document.querySelector(".add-plan");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
    });

    document.addEventListener("DOMContentLoaded", function () {
        const chatBox = document.querySelector(".chat-box"); 
        const sendButton = document.querySelector(".send-btn"); 
        const threebtn = document.querySelector(".threebtn");
        const chatBot = document.querySelector(".chatbot");
    
        if (sendButton && chatBox) {
            sendButton.addEventListener("click", function () {
                chatBox.style.display = "none"; 
                threebtn.style.display = "flex";
                chatBot.style.display = "block";
            });
        }
    });

    //chat

    let Block__Messages = document.getElementById('Block__Messages'),
    Input = document.getElementById('Input'), 
    Image__Site = document.getElementById('send-btn');
    console.log(Block__Messages, Input, Image);
    let num = 0;
    let ValueInput;

    Image__Site.addEventListener('click', ()=>{
        

        if(num == 0){
        ValueInput = Input.value ,
        Message = `<div class="Message__Element Bot"> <div class = "Message" id="Message">${ValueInput}</div><img src="/photo/user.png" alt="" style="height: 50px;" ></div>`;
        Block__Messages.innerHTML += Message;
        Input.value = '';
        let arrMessage = Block__Messages.querySelectorAll('#Message');
        if(arrMessage.length > 30){
            Block__Messages.firstChild.remove();
        }; num = 1;}else if(num == 1){
            
            Message = `<div class="Message__Element User"> <img src="/photo/bunny.png" alt="" style="height: 50px;" ><div class = "Message" id="Message"></div></div>`;
            Block__Messages.innerHTML += Message;
            Input.value = '';
            let arrMessage = Block__Messages.querySelectorAll('#Message');
            if(arrMessage.length > 30){
                Block__Messages.firstChild.remove();
            }
        num = 0;}







        
        
            Block__Messages.scrollTop = Block__Messages.scrollWidth + 100000;
    });
