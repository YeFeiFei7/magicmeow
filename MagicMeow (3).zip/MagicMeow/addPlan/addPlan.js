//folder
document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("toggle-btn");
    const closeBtn = document.getElementById("close-btn");
    const illustration = document.querySelector(".illustration");
    const folder = document.querySelector(".folder");

   
    toggleBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        folder.style.display = "block";
        closeBtn.style.display = "inline"; 
    });

    
    closeBtn.addEventListener("click", function () {
        folder.style.display = "none";
        illustration.style.display = "block";
        closeBtn.style.display = "none"; 
    });
});
//repeat
document.addEventListener("DOMContentLoaded", function () {
    const repeatBtn = document.getElementById("repeat-btn");
    const cancelBtn = document.getElementById("cancel-btn");
    const illustration = document.querySelector(".illustration");
    const repeat = document.querySelector(".selection-container");

   
    repeatBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        repeat.style.display = "block";
        cancelBtn.style.display = "inline"; 
    });

    
    cancelBtn.addEventListener("click", function () {
        repeat.style.display = "none";
        illustration.style.display = "block";
        cancelBtn.style.display = "none"; 
    });
});

//quadrants
document.addEventListener("DOMContentLoaded", function () {
    const quadrantsBtn = document.getElementById("quadrants-btn");
    const closeqBtn = document.getElementById("closeq-btn");
    const illustration = document.querySelector(".illustration");
    const quad = document.querySelector(".quadrants");

   
    quadrantsBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        quad.style.display = "flex";
        closeqBtn.style.display = "inline"; 
    });

    
    closeqBtn.addEventListener("click", function () {
        quad.style.display = "none";
        illustration.style.display = "block";
        closeqBtn.style.display = "none"; 
    });
});

//time
document.addEventListener("DOMContentLoaded", function () {
    const timeBtn = document.getElementById("time-btn");
    const closetBtn = document.getElementById("closet-btn");
    const illustration = document.querySelector(".illustration");
    const time = document.querySelector(".time-picker-container");

   
    timeBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        time.style.display = "block";
        closetBtn.style.display = "inline"; 
    });

    
    closetBtn.addEventListener("click", function () {
        time.style.display = "none";
        illustration.style.display = "block";
        closetBtn.style.display = "none"; 
    });
});
