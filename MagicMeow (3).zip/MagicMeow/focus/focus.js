//Sidebar
document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const addPlanButton = document.querySelector(".add-plan");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
    });




//Records-popup
    document.addEventListener("DOMContentLoaded", function () {
        const iconTrigger = document.querySelector(".icon-trigger"); // Иконка в main-content
        const recordsPopup = document.querySelector(".records-popup"); // Плашка "Focus Records"
        const backBtn = document.querySelector(".back-btn"); // Кнопка возврата в плашке
    
        //"Records Popup"
        iconTrigger.addEventListener("click", function () {
            recordsPopup.style.display = "flex"; 
        });
    
        // стрелку (Back)
        backBtn.addEventListener("click", function () {
            recordsPopup.style.display = "none"; 
        });
    });



document.addEventListener("DOMContentLoaded", function () {
        const mainContent = document.querySelector(".main-content");
        const addFocusBtn = document.querySelector(".add-focus-btn");
        const startBtn = document.querySelector(".start-btn");
        const focusTitle = document.querySelector(".focus-title");
        let isTimerRunning = false;


        function startTimer() {
            if (focusTitle) {
                
                focusTitle.textContent = "READING..."; 
                focusTitle.style.marginBottom="100px";
            }
            if (addFocusBtn) {
                addFocusBtn.style.display = "none"; 
            }
            if (startBtn) {
                if (isTimerRunning) {

                } else {
                    startBtn.textContent = "Pause";
                    startBtn.addEventListener('click', ()=>{
                        showPauseOptions();
                    });
                }
                isTimerRunning = !isTimerRunning; 
            }
        }


        function showPauseOptions() {

            startBtn.style.display = "none"; // "Pause"
            let btnContainer = document.getElementById("fin-cont");
            btnContainer.style.marginTop="-80px";
    
            
            const finishBtn = document.createElement("button");
            finishBtn.textContent = "Finish";
            finishBtn.classList.add("finish-btn");
            
    
            const continueBtn = document.createElement("button");
            continueBtn.textContent = "Continue";
            continueBtn.classList.add("continue-btn");
    
            
            btnContainer.appendChild(finishBtn);
            btnContainer.appendChild(continueBtn);
    
        
            finishBtn.addEventListener("click", ()=>{
                    
                    finishBtn.remove();
                    continueBtn.remove();
                    pon4ik54();

            });

        }
        function pon4ik54(){

            startTimer();
            focusTitle.textContent = "READING...";
            startBtn.style.display = "block"; // Возвращаем кнопку "Pause"
            startBtn.textContent = "Start"; // Оставляем "Pause"
            addFocusBtn.style.display = "flex";
            startBtn.style.display = "none";

            isTimerRunning = true; 
       
        }
    
       
        function createPopup(type) {
            // Проверяем, есть ли activ plashka
            if (document.querySelector(".popup-box.active")) return;
    
            let popupContent = "";
            if (type === "add-focus") {
                popupContent = `<div class='durationName'></div>
                    <div class="popup-content">
                        
                        <div class="input-container">
                            <button class="play-btn" style="background:none; border:none;" >▶</button>
                            <input type="text" value="30:00" style="font-size:50px;">
                            <span>MIN</span>
                        </div>
                        <div class="popup-buttons">
                            <button class="cancel-btn">Cancel</button>
                            <button class="confirm-btn">Confirm</button>
                        </div>
                    </div>`;
            } else if (type === "start-timer") {
              startTimer(); 
            }
    
            const popup = document.createElement("div");
            popup.classList.add("popup-box", "active", type);
            popup.innerHTML = popupContent;
    
            mainContent.appendChild(popup);
            updateBackground(); 
    
            // Закрытие плашки (Cancel)
            const cancelBtn = popup.querySelector(".cancel-btn");
            if (cancelBtn) {
                cancelBtn.addEventListener("click", function () {
                    popup.remove();
                    updateBackground();
                });
            }
    
            // Закрытие плашки (Confirm)
            popup.querySelector(".confirm-btn").addEventListener("click", function () {
                popup.remove();
                startTimer();
                updateBackground();
            });
        }



        
    
        // Функция для проверки открытых плашек и управления фоном/ НУЖНО
        function updateBackground() {
            const popups = document.querySelectorAll(".popup-box.active");
            if (popups.length > 0) {
                mainContent.classList.add("has-popup"); // Убираем белый фон
            } else {
                mainContent.classList.remove("has-popup"); // Возвращаем белый фон
            }
        }
    
        // Обработчики событий для кнопок
        addFocusBtn.addEventListener("click", function () {
            createPopup("add-focus");
        });
    
        startBtn.addEventListener("click", function () {
            createPopup("start-timer");
        });
    });
    

 