//Sidebar
document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const addPlanButton = document.querySelector(".add-plan");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
    });


//reminder
const showBtn = document.getElementById("bunny");
const panel = document.getElementById("reminderPanel");

showBtn.addEventListener("click", () => {
  if (panel.style.display === "none") {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
});

// monthly(calendar)
const calendarDays = document.getElementById("calendarDays");
const month = document.getElementById("month");
const year = document.getElementById("year");
const prevMonth = document.getElementById("prevMonth");
const nextMonth = document.getElementById("nextMonth");
const weekRange = document.getElementById("weekRange");

let currentDate = new Date();

function formatDate(date) {
  const d = String(date.getDate()).padStart(2, "0");
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const y = date.getFullYear();
  return `${d}.${m}.${y}`;
}

function getWeekRange(date) {
  const day = date.getDay(); // 0 - Sunday, 1 - Monday, ...
  const diffToMonday = day === 0 ? -6 : 1 - day;
  const monday = new Date(date);
  monday.setDate(date.getDate() + diffToMonday);

  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);

  weekRange.textContent = `${formatDate(monday)} - ${formatDate(sunday)}`;
}

function renderCalendar(date) {
    calendarDays.innerHTML = "";
    year.textContent = date.getFullYear();
    month.textContent = date.toLocaleDateString("en-US", { month: "long" });
  
    const firstDay = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    const lastDate = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  
    const offset = firstDay === 0 ? 6 : firstDay - 1;
    let row = document.createElement("tr");
  
    for (let i = 0; i < offset; i++) {
      row.appendChild(document.createElement("td"));
    }
  
    const today = new Date();
  
    for (let day = 1; day <= lastDate; day++) {
      const cell = document.createElement("td");
  
      // Вставляем число обычным способом
      const daySpan = document.createElement("span");
      daySpan.textContent = day;
      daySpan.classList.add("calendar-day-number");
      cell.appendChild(daySpan);
  
      // Добавляем иконку, если это сегодня
      if (
        day === today.getDate() &&
        date.getMonth() === today.getMonth() &&
        date.getFullYear() === today.getFullYear()
      ) {
        const icon = document.createElement("img");
        icon.src = "../photo/catcircle.png";
        icon.alt = "Today";
        icon.className = "today-overlay-icon";
        cell.appendChild(icon);
        cell.classList.add("has-today-icon");
      }
  
      if ((offset + day) % 7 === 0) {
        row.appendChild(cell);
        calendarDays.appendChild(row);
        row = document.createElement("tr");
      } else {
        row.appendChild(cell);
      }
    }

  if (row.children.length) {

    while (row.children.length < 7) {
        row.appendChild(document.createElement("td"));
    }
    calendarDays.appendChild(row);
  } 
  getWeekRange(new Date());
}

prevMonth.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar(currentDate);
});

nextMonth.addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar(currentDate);
});

renderCalendar(currentDate);
