//Sidebar
document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
    });


//reminder
const showBtn = document.getElementById("bunny");
const panel = document.getElementById("reminderPanel");

showBtn.addEventListener("click", () => {
  if (panel.style.display === "none") {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
});



  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const monthEl = document.getElementById("month");
  const yearEl = document.getElementById("year");
  const weekRangeEl = document.getElementById("weekRange");
  const calendarGrid = document.getElementById("calendarGrid");

  let currentDate = new Date();

  function renderCalendar(date) {
    calendarGrid.innerHTML = "";

    const year = date.getFullYear();
    const month = date.getMonth();

    const firstDay = new Date(year, month, 1);
    const startDay = (firstDay.getDay() + 6) % 7; // понедельник = 0
    const daysInMonth = new Date(year, month + 1, 0).getDate();

   
    monthEl.textContent = monthNames[month].toUpperCase();
    yearEl.textContent = year;

    let dayCounter = 1 - startDay;

    for (let i = 0; i < 42; i++) {
      const cell = document.createElement("div");
      cell.classList.add("calendar-cell");

      const cellDate = new Date(year, month, dayCounter);

      if (dayCounter > 0 && dayCounter <= daysInMonth) {
        const dayNumber = document.createElement("div");
        dayNumber.classList.add("day-number");
        dayNumber.textContent = dayCounter;
        cell.appendChild(dayNumber);
      
        if (isToday(cellDate)) {
          const img = document.createElement("img");
          img.src = "../photo/catcircle.png"; 
          img.alt = "today";
          img.classList.add("today-icon");
          cell.appendChild(img);
        }
      } else {
        const fadedNumber = document.createElement("div");
        fadedNumber.classList.add("day-number");
        fadedNumber.textContent = cellDate.getDate();
        fadedNumber.style.color = "#bbb";
        cell.appendChild(fadedNumber);
      }

      calendarGrid.appendChild(cell);
      dayCounter++;
    }
  }

  function isToday(date) {
    const today = new Date();
    return date.getDate() === today.getDate() &&
           date.getMonth() === today.getMonth() &&
           date.getFullYear() === today.getFullYear();
  }

  function getMonday(date) {
    const d = new Date(date);
    const day = d.getDay();
    const diff = day === 0 ? -6 : 1 - day;
    d.setDate(d.getDate() + diff);
    return d;
  }

  function formatDate(date) {
    return `${String(date.getDate()).padStart(2, '0')}.${String(date.getMonth() + 1).padStart(2, '0')}.${date.getFullYear()}`;
  }

  document.getElementById("prevMonth").addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    renderCalendar(currentDate);
  });

  document.getElementById("nextMonth").addEventListener("click", () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    renderCalendar(currentDate);
  });

  // Показываем текущую неделю один раз при загрузке
  const todayMonday = getMonday(new Date());
  const todaySunday = new Date(todayMonday);
  todaySunday.setDate(todayMonday.getDate() + 6);
  weekRangeEl.textContent = `${formatDate(todayMonday)} – ${formatDate(todaySunday)}`;

  renderCalendar(currentDate);



//plan, plan-popup
function addPlanByDate(dateString, text, quadrantClass) {
  const cell = document.querySelector(`.calendar-cell[data-date="${dateString}"]`);
  if (!cell) return;

  const plan = document.createElement("div");
  plan.classList.add("plan-quadrant", quadrantClass);

  const name = document.createElement("div");
  name.classList.add("plan-name");
  name.textContent = text;
  plan.appendChild(name);

  plan.addEventListener("click", () => {
    document.getElementById("popupText").textContent = text;
    document.getElementById("planPopup").style.display = "block";
  });

  let planWrapper = cell.querySelector(".plan");
  if (!planWrapper) {
    planWrapper = document.createElement("div");
    planWrapper.classList.add("plan");
    cell.appendChild(planWrapper);
  }

  planWrapper.appendChild(plan);
}


document.querySelector(".back-btn").addEventListener("click", () => {
  document.getElementById("planPopup").style.display = "none";
});

window.addEventListener("click", (e) => {
  const popup = document.getElementById("planPopup");
  if (e.target === popup) popup.style.display = "none";
});

// // Пример задач
// addPlanByDate("2025-04-04", "Midterm", "top-right");
// addPlanByDate("2025-04-10", "Assignment", "bottom-left");
// addPlanByDate("2025-04-14", "Plan Demo", "top-left");