//Sidebar
document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const addPlanButton = document.querySelector(".add-plan");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
    });


//reminder
const showBtn = document.getElementById("bunny");
const panel = document.getElementById("reminderPanel");

showBtn.addEventListener("click", () => {
  if (panel.style.display === "none") {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
});

const backBtn = document.querySelector('.back-btn');
const createPanel = document.getElementById('createPanel');
const addFolderBtn = document.getElementById('addFolder');


backBtn.addEventListener('click', () => {
  createPanel.style.display = 'none';
});


addFolderBtn.addEventListener('click', () => {
  createPanel.style.display = 'block';
});