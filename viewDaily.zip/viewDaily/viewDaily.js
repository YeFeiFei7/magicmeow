//Sidebar
document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
    });


//reminder
const showBtn = document.getElementById("bunny");
const panel = document.getElementById("reminderPanel");

showBtn.addEventListener("click", () => {
  if (panel.style.display === "none") {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
});

const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];

  const currentDayDisplay = document.getElementById("currentDayDisplay");
  const monthEl = document.getElementById("month");
  const yearEl = document.getElementById("year");
  const weekRange = document.getElementById("weekRange");
  const prevDayBtn = document.getElementById("prevDay");
  const nextDayBtn = document.getElementById("nextDay");

  let currentDate = new Date();
  let currentMonday = getMonday(currentDate); 

  function getMonday(date) {
    const copied = new Date(date);
    const day = copied.getDay();
    const diff = day === 0 ? -6 : 1 - day;
    copied.setDate(copied.getDate() + diff);
    return copied;
  }

  function formatDate(date) {
    return `${String(date.getDate()).padStart(2, '0')}.${String(date.getMonth() + 1).padStart(2, '0')}.${date.getFullYear()}`;
  }

  function updateDisplay() {
    currentDayDisplay.textContent = formatDate(currentDate);
    monthEl.textContent = monthNames[currentDate.getMonth()].toUpperCase();
    yearEl.textContent = currentDate.getFullYear();


    const monday = getMonday(currentDate);
    if (monday.getTime() !== currentMonday.getTime()) {
      currentMonday = monday;
    }

    const sunday = new Date(currentMonday);
    sunday.setDate(currentMonday.getDate() + 6);
    weekRange.textContent = `${formatDate(currentMonday)} – ${formatDate(sunday)}`;
  }

  prevDayBtn.addEventListener("click", () => {
    currentDate.setDate(currentDate.getDate() - 1);
    updateDisplay();
  });

  nextDayBtn.addEventListener("click", () => {
    currentDate.setDate(currentDate.getDate() + 1);
    updateDisplay();
  });

  updateDisplay();
