document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
});

document.addEventListener("DOMContentLoaded", function () {
    const chatBox = document.querySelector(".chat-box");
    const sendButton = document.querySelector(".send-btn");
    const threebtn = document.querySelector(".threebtn");
    const chatBot = document.querySelector(".chatbot");

    if (sendButton && chatBox) {
        sendButton.addEventListener("click", function () {
            chatBox.style.display = "none";
            threebtn.style.display = "flex";
            chatBot.style.display = "block";
        });
    }
});
//reminder
const showBtn = document.getElementById("bunny");
const panel = document.getElementById("reminderPanel");

showBtn.addEventListener("click", () => {
    if (panel.style.display === "none") {
        panel.style.display = "block";
    } else {
        panel.style.display = "none";
    }
});
//notification
const showNot = document.getElementById("notification");
const popup = document.getElementById("notificationPopup");

showNot.addEventListener("click", () => {
    if (popup.style.visibility === "hidden") {
        popup.style.visibility = "visible";
    } else {
        popup.style.visibility = "hidden";
    }
});

//chat
const Block__Messages = document.getElementById('Block__Messages');
const Input = document.getElementById('Input');
const SendBtn = document.getElementById('send-btn');

SendBtn.addEventListener('click', () => {
    const value = Input.value.trim();
    if (value === '') return;


    const userMessage = `
            <div class="Message__Element User">
                <div class="Message">${value}</div>
                <img src="../photo/user.png" alt="" style="height: 50px; border-radius: 50%; border: 3px solid black; object-fit: cover; margin-left: 5px;">
            </div>
        `;
    Block__Messages.innerHTML += userMessage;

    Input.value = '';


    setTimeout(() => {
        const botMessage = `
                <div class="Message__Element Bot">
                    <img src="../photo/bunny.png" alt="" style="height: 50px;">
                    <div class="Message">...</div>
                </div>
            `;
        Block__Messages.innerHTML += botMessage;

        Block__Messages.scrollTop = Block__Messages.scrollHeight;

        const allMessages = Block__Messages.querySelectorAll('.Message__Element');
        if (allMessages.length > 30) {
            Block__Messages.removeChild(allMessages[0]);
        }

    }, 400);

    Block__Messages.scrollTop = Block__Messages.scrollHeight;
});

