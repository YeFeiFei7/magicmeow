//Sidebar
document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.querySelector(".sidebar");
  const toggleBtn = document.querySelector(".toggle-btn");
  const plusIcon = document.querySelector(".plus-icon");


  toggleBtn.addEventListener("click", function () {
    sidebar.classList.toggle("open");


    if (sidebar.classList.contains("open")) {
      plusIcon.style.display = "none";
    } else {
      plusIcon.style.display = "block";
    }
  });
});


//reminder
const showBtn = document.getElementById("bunny");
const panel = document.getElementById("reminderPanel");

showBtn.addEventListener("click", () => {
  if (panel.style.display === "none") {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
});



const monthNames = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const monthEl = document.getElementById("month");
const yearEl = document.getElementById("year");
const weekRangeEl = document.getElementById("weekRange");
const calendarGrid = document.getElementById("calendarGrid");

let currentDate = new Date();

function renderCalendar(date) {
  calendarGrid.innerHTML = "";

  const year = date.getFullYear();
  const month = date.getMonth();

  const firstDay = new Date(year, month, 1);
  const startDay = (firstDay.getDay() + 6) % 7; // понедельник = 0
  const daysInMonth = new Date(year, month + 1, 0).getDate();


  monthEl.textContent = monthNames[month].toUpperCase();
  yearEl.textContent = year;

  let dayCounter = 1 - startDay;

  for (let i = 0; i < 42; i++) {
    const cell = document.createElement("div");
    cell.classList.add("calendar-cell");

    const cellDate = new Date(year, month, dayCounter);

    if (dayCounter > 0 && dayCounter <= daysInMonth) {
      const dayNumber = document.createElement("div");
      dayNumber.classList.add("day-number");
      dayNumber.textContent = dayCounter;
      cell.appendChild(dayNumber);

      if (isToday(cellDate)) {
        const img = document.createElement("img");
        img.src = "../photo/catcircle.png";
        img.alt = "today";
        img.classList.add("today-icon");
        cell.appendChild(img);
      }
    } else {
      const fadedNumber = document.createElement("div");
      fadedNumber.classList.add("day-number");
      fadedNumber.textContent = cellDate.getDate();
      fadedNumber.style.color = "#bbb";
      cell.appendChild(fadedNumber);
    }

    calendarGrid.appendChild(cell);
    dayCounter++;
  }
}

function isToday(date) {
  const today = new Date();
  return date.getDate() === today.getDate() &&
    date.getMonth() === today.getMonth() &&
    date.getFullYear() === today.getFullYear();
}

function getMonday(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + diff);
  return d;
}

function formatDate(date) {
  return `${String(date.getDate()).padStart(2, '0')}.${String(date.getMonth() + 1).padStart(2, '0')}.${date.getFullYear()}`;
}

document.getElementById("prevMonth").addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() - 1);
  renderCalendar(currentDate);
});

document.getElementById("nextMonth").addEventListener("click", () => {
  currentDate.setMonth(currentDate.getMonth() + 1);
  renderCalendar(currentDate);
});


const todayMonday = getMonday(new Date());
const todaySunday = new Date(todayMonday);
todaySunday.setDate(todayMonday.getDate() + 6);
weekRangeEl.textContent = `${formatDate(todayMonday)} – ${formatDate(todaySunday)}`;

renderCalendar(currentDate);


// plan-details
const toggle = document.getElementById("reminderToggle");
toggle.addEventListener("change", () => {
  console.log("Reminder switched:", toggle.checked);
});
document.querySelector(".back-arrow-plan").addEventListener("click", () => {
  document.getElementById("planDetails").style.display = "none";
});


//chat
const Block__Messages = document.getElementById('Block__Messages');
const Input = document.getElementById('Input');
const SendBtn = document.getElementById('send-btn');

SendBtn.addEventListener('click', () => {
  const value = Input.value.trim();
  if (value === '') return;


  const userMessage = `
            <div class="Message__Element User">
                <div class="Message">${value}</div>
                <img src="../photo/user.png" alt="" style="height: 50px; border-radius: 50%; border: 3px solid black; object-fit: cover; margin-left: 5px;">
            </div>
        `;
  Block__Messages.innerHTML += userMessage;

  Input.value = '';


  setTimeout(() => {
    const botMessage = `
                <div class="Message__Element Bot">
                    <img src="../photo/bunny.png" alt="" style="height: 50px;">
                    <div class="Message">...</div>
                </div>
            `;
    Block__Messages.innerHTML += botMessage;

    Block__Messages.scrollTop = Block__Messages.scrollHeight;

    const allMessages = Block__Messages.querySelectorAll('.Message__Element');
    if (allMessages.length > 30) {
      Block__Messages.removeChild(allMessages[0]);
    }

  }, 400);

  Block__Messages.scrollTop = Block__Messages.scrollHeight;
});

