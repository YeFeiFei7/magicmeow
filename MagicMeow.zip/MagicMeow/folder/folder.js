//Sidebar
document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.querySelector(".sidebar");
  const toggleBtn = document.querySelector(".toggle-btn");
  const plusIcon = document.querySelector(".plus-icon");


  toggleBtn.addEventListener("click", function () {
    sidebar.classList.toggle("open");


    if (sidebar.classList.contains("open")) {
      plusIcon.style.display = "none";
    } else {
      plusIcon.style.display = "block";
    }
  });
});




//reminder
const showBtn = document.getElementById("bunny");
const panel = document.getElementById("reminderPanel");

showBtn.addEventListener("click", () => {
  if (panel.style.display === "none") {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
});
//create-poup
const backBtnCreate = document.querySelector('.back-btn');
const backBtnEdit = document.getElementById('backBtn');
const createPanel = document.getElementById('createPanel');
const editPanel = document.getElementById('editPanel');
const editBtn = document.getElementById('editBtn');
const addFolderBtn = document.getElementById('addFolder');
const createBtn = document.getElementById("createBtn");
const illustration = document.getElementById("illustration");
const folderBox = document.getElementById("folder-box");



backBtnCreate.addEventListener('click', () => {
  createPanel.style.display = 'none';
});

backBtnEdit.addEventListener('click', () => {
  editPanel.style.display = 'none';
  folderBox.style.opacity = "100%";
});

addFolderBtn.addEventListener('click', () => {
  createPanel.style.display = 'block';
});


//create folder

createBtn.addEventListener("click", function () {
  illustration.style.display = "none";
  folderBox.style.display = "flex";
  createPanel.style.display = "none";
});
// edit folder
editBtn.addEventListener("click", function () {
  folderBox.style.opacity = "60%";
  editPanel.style.display = "block";
});



//chat
const Block__Messages = document.getElementById('Block__Messages');
const Input = document.getElementById('Input');
const SendBtn = document.getElementById('send-btn');

SendBtn.addEventListener('click', () => {
  const value = Input.value.trim();
  if (value === '') return;


  const userMessage = `
            <div class="Message__Element User">
                <div class="Message">${value}</div>
                <img src="../photo/user.png" alt="" style="height: 50px; border-radius: 50%; border: 3px solid black; object-fit: cover; margin-left: 5px;">
            </div>
        `;
  Block__Messages.innerHTML += userMessage;

  Input.value = '';


  setTimeout(() => {
    const botMessage = `
                <div class="Message__Element Bot">
                    <img src="../photo/bunny.png" alt="" style="height: 50px;">
                    <div class="Message">...</div>
                </div>
            `;
    Block__Messages.innerHTML += botMessage;

    Block__Messages.scrollTop = Block__Messages.scrollHeight;

    const allMessages = Block__Messages.querySelectorAll('.Message__Element');
    if (allMessages.length > 30) {
      Block__Messages.removeChild(allMessages[0]);
    }

  }, 400);

  Block__Messages.scrollTop = Block__Messages.scrollHeight;
});
