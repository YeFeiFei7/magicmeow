//Sidebar
document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
});




//Records-popup
document.addEventListener("DOMContentLoaded", function () {
    const iconTrigger = document.querySelector(".icon-trigger");
    const recordsPopup = document.querySelector(".records-popup");
    const backBtn = document.querySelector(".back-btn");
    const timer = document.getElementById("timer");
    const addFocusBtn = document.getElementById("addFocusBtn");
    const startBtn = document.getElementById("startBtn");


    //"Records Popup"
    iconTrigger.addEventListener("click", function () {
        recordsPopup.style.display = "flex";
        timer.style.visibility = "hidden";
        addFocusBtn.style.visibility = "hidden";
        startBtn.style.visibility = "hidden";
    });

    // (Back)
    backBtn.addEventListener("click", function () {
        recordsPopup.style.display = "none";
        timer.style.visibility = "visible";
        addFocusBtn.style.visibility = "visible";
        startBtn.style.visibility = "visible";
    });
});

//Focus-duration
document.addEventListener("DOMContentLoaded", function () {
    const startBtn = document.getElementById("startBtn");


    const addFocusBtn = document.querySelector(".add-focus-btn");
    const popupBox = document.getElementById("focusDurationPopup");
    const cancelBtn = popupBox.querySelector(".cancel-btn");
    const confirmBtn = document.getElementById("confirmBtn");
    const pauseBtn = document.getElementById("pauseBtn");
    const focusTitle = document.getElementById("focusTitle");
    const finCont = document.getElementById("fin-cont");
    const continueBtn = document.querySelector(".continue-btn");
    const showConfirm = document.getElementById("showConfirm");
    const confirmPopup = document.getElementById("confirmPopup");
    const cancelConfirm = document.getElementById("cancelConfirm");
    const confirmFinishBtn = document.getElementById("confirmFinishBtn");
    const timer = document.getElementById("timer");
    const timerDisplay = document.getElementById("timerDisplay");
    const elements = document.querySelectorAll(".icon-trigger, .add-focus-btn, .focus-title, .toggle-btn, .timer-circle, .time-display");

    addFocusBtn.addEventListener("click", function () {
        popupBox.classList.add("active");
        startBtn.style.visibility = "hidden";
        timer.style.borderColor = "black";
        timerDisplay.style.color = "black";
        addFocusBtn.style.backgroundColor = "white";
        elements.style.opacity = "60%";

    });

    cancelBtn.addEventListener("click", function () { //
        popupBox.classList.remove("active");
        startBtn.style.visibility = "visible";
        timer.style.borderColor = "#FCE803";
        timerDisplay.style.color = "white";
        addFocusBtn.style.background = "none";
    });

    confirmBtn.addEventListener("click", function () {
        popupBox.classList.remove("active");
        focusTitle.textContent = "Reading...";
        pauseBtn.style.display = "block";
        addFocusBtn.style.display = "none";
        startBtn.style.display = "none";
        timer.style.borderColor = "#FCE803";
        timerDisplay.style.color = "white";
    });

    pauseBtn.addEventListener("click", function () {
        pauseBtn.style.display = "none";
        finCont.style.display = "flex";
    });


    continueBtn.addEventListener("click", function () { //
        finCont.style.display = "none";
        pauseBtn.style.display = "block";
        timer.style.borderColor = "#FCE803";
        timerDisplay.style.color = "white";
    });

    showConfirm.addEventListener("click", function () {
        confirmPopup.style.display = "block";
        timer.style.borderColor = "black";
        timerDisplay.style.display = "none";
        finCont.style.display = "none";
    });

    cancelConfirm.addEventListener("click", function () { //
        confirmPopup.style.display = "none";
        finCont.style.display = "none";
        pauseBtn.style.display = "block";
        timer.style.borderColor = "#FCE803";
        timerDisplay.style.color = "white";
    });

    confirmFinishBtn.addEventListener("click", function () {
        confirmPopup.style.display = "none";
        focusTitle.textContent = "FOCUS TIME";
        addFocusBtn.style.display = "flex";
        addFocusBtn.style.marginop = "50px";
        finCont.style.display = "none";
        startBtn.style.visibility = "visible";
        startBtn.style.display = "block";
        timerDisplay.style.color = "white";
        timerDisplay.style.display = "block";
        timer.style.borderColor = "#FCE803";
    });
});


//Start-btn
document.addEventListener("DOMContentLoaded", function () {
    const addFocusBtn = document.querySelector(".add-focus-btn");
    const popupBox = document.getElementById("focusDurationPopup");
    const pauseBtn = document.getElementById("pauseBtn");
    const focusTitle = document.getElementById("focusTitle");
    const startBtn = document.getElementById("startBtn");

    startBtn.addEventListener("click", function () {
        popupBox.classList.remove("active");
        focusTitle.textContent = "Reading...";
        pauseBtn.style.display = "block";
        addFocusBtn.style.display = "none";
        startBtn.style.display = "none";

    });
});


//chat
const Block__Messages = document.getElementById('Block__Messages');
const Input = document.getElementById('Input');
const SendBtn = document.getElementById('send-btn');

SendBtn.addEventListener('click', () => {
    const value = Input.value.trim();
    if (value === '') return;


    const userMessage = `
            <div class="Message__Element User">
                <div class="Message">${value}</div>
                <img src="../photo/user.png" alt="" style="height: 50px; border-radius: 50%; border: 3px solid black; object-fit: cover; margin-left: 5px;">
            </div>
        `;
    Block__Messages.innerHTML += userMessage;

    Input.value = '';


    setTimeout(() => {
        const botMessage = `
                <div class="Message__Element Bot">
                    <img src="../photo/bunny.png" alt="" style="height: 50px;">
                    <div class="Message">...</div>
                </div>
            `;
        Block__Messages.innerHTML += botMessage;

        Block__Messages.scrollTop = Block__Messages.scrollHeight;

        const allMessages = Block__Messages.querySelectorAll('.Message__Element');
        if (allMessages.length > 30) {
            Block__Messages.removeChild(allMessages[0]);
        }

    }, 400);

    Block__Messages.scrollTop = Block__Messages.scrollHeight;
});
