//Sidebar
document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.querySelector(".sidebar");
  const toggleBtn = document.querySelector(".toggle-btn");
  const plusIcon = document.querySelector(".plus-icon");


  toggleBtn.addEventListener("click", function () {
    sidebar.classList.toggle("open");


    if (sidebar.classList.contains("open")) {
      plusIcon.style.display = "none";
    } else {
      plusIcon.style.display = "block";
    }
  });
});

//reminder

const showBtn = document.getElementById("bunny");
const panel = document.getElementById("reminderPanel");

showBtn.addEventListener("click", () => {
  if (panel.style.display === "none") {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
});
//tabs
function switchTab(tabId) {
  const tabIds = ['daily-content', 'monthly-content', 'all-content'];

  tabIds.forEach(id => {
    const tab = document.getElementById(id);
    if (tab) {
      tab.style.display = 'none';
    }
  });

  const selectedTab = document.getElementById(tabId);
  if (selectedTab) {
    selectedTab.style.display = 'block';
  }
}

window.addEventListener('DOMContentLoaded', () => {
  switchTab('daily-content');
});


//plan
const monthNames = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];
const currentMonth = new Date().getMonth();
document.getElementById('progressTitle').innerHTML = `<span style="color: #CEB3FF; font-weight: lighter;">${monthNames[currentMonth].toUpperCase()}</span> PLAN PROGRESS:`;

const pieData = {
  labels: ['Red', 'Blue', 'Yellow', 'Green'],
  datasets: [{
    data: [3, 2, 2, 1],
    backgroundColor: ['#F4A099', '#A3C1F3', '#FDE9A8', '#C9E2D0'],
    borderColor: 'black',
    borderWidth: 2
  }]
};

const barData = {
  labels: ['', '', '', ''],
  datasets: [{
    label: '',
    data: [3, 2, 2, 1],
    backgroundColor: ['#F4A099', '#A3C1F3', '#FDE9A8', '#C9E2D0'],
    borderColor: 'black',
    borderWidth: 2
  }]
};

const ctx = document.getElementById('chartCanvas').getContext('2d');
let currentChart = new Chart(ctx, {
  type: 'pie',
  data: pieData,
  options: {
    responsive: false,
    plugins: { legend: { display: false } }
  }
});

const toggle = document.getElementById('chartToggle');
toggle.addEventListener('click', () => {
  toggle.classList.toggle('active');
  currentChart.destroy();
  const type = toggle.classList.contains('active') ? 'bar' : 'pie';
  const data = toggle.classList.contains('active') ? barData : pieData;
  currentChart = new Chart(ctx, {
    type,
    data,
    options: {
      responsive: false,
      plugins: { legend: { display: false } },
      scales: type === 'bar' ? {
        x: {
          grid: { display: false },
          ticks: { display: false },
          title: { display: false }
        },
        y: {
          grid: { display: false },
          ticks: { display: false },
          title: { display: false }
        }
      } : {}
    }
  });
});
// Weekly Chart
const data = [
  { day: "M", value: 0, color: "#C9E2D0" },
  { day: "T", value: 60, color: "#CEB3FF" },
  { day: "W", value: 20, color: "#F4A099" },
  { day: "T", value: 3, color: "#FDE9A8" },
  { day: "F", value: 40, color: "#A3C1F3" },
  { day: "S", value: 48, color: "#FF8CE9" },
  { day: "S", value: 45, color: "#93B493" },
];

const maxValue = 70; // its working somehow
const container = document.getElementById("barContainer");
const yAxis = document.getElementById("yAxisMarks");


data.forEach(item => {
  const group = document.createElement("div");
  group.className = "bar-group";

  const bar = document.createElement("div");
  bar.className = "bar-focus";

  const heightPercent = Math.min(item.value / maxValue, 1) * 100;
  const barMaxHeight = 160;
  bar.style.height = `${(item.value / maxValue) * barMaxHeight}px`;
  bar.style.backgroundColor = item.color;

  const label = document.createElement("div");
  label.className = "day-label";
  label.textContent = item.day;

  group.appendChild(bar);
  group.appendChild(label);
  container.appendChild(group);
});




//for daily

const pieDataDaily = {
  labels: ['Red', 'Blue', 'Yellow', 'Green'],
  datasets: [{
    data: [3, 2, 2, 1],
    backgroundColor: ['#F4A099', '#A3C1F3', '#FDE9A8', '#C9E2D0'],
    borderColor: 'black',
    borderWidth: 2
  }]
};

const barDataDaily = {
  labels: ['', '', '', ''],
  datasets: [{
    label: '',
    data: [3, 2, 2, 1],
    backgroundColor: ['#F4A099', '#A3C1F3', '#FDE9A8', '#C9E2D0'],
    borderColor: 'black',
    borderWidth: 2
  }]
};

const ctxDaily = document.getElementById('chartCanvas-daily').getContext('2d');
let currentChartDaily = new Chart(ctxDaily, {
  type: 'pie',
  data: pieDataDaily,
  options: {
    responsive: false,
    plugins: { legend: { display: false } }
  }
});

const toggleDaily = document.getElementById('chartToggle-daily');
toggleDaily.addEventListener('click', () => {
  toggleDaily.classList.toggle('active');
  currentChartDaily.destroy();
  const type = toggleDaily.classList.contains('active') ? 'bar' : 'pie';
  const data = toggleDaily.classList.contains('active') ? barDataDaily : pieDataDaily;
  currentChartDaily = new Chart(ctxDaily, {
    type,
    data,
    options: {
      responsive: false,
      plugins: { legend: { display: false } },
      scales: type === 'bar' ? {
        x: {
          grid: { display: false },
          ticks: { display: false },
          title: { display: false }
        },
        y: {
          grid: { display: false },
          ticks: { display: false },
          title: { display: false }
        }
      } : {}
    }
  });
});


// Weekly Chart
const weeklyData = [
  { day: "M", value: 0, color: "#C9E2D0" },
  { day: "T", value: 60, color: "#CEB3FF" },
  { day: "W", value: 20, color: "#F4A099" },
  { day: "T", value: 3, color: "#FDE9A8" },
  { day: "F", value: 40, color: "#A3C1F3" },
  { day: "S", value: 48, color: "#FF8CE9" },
  { day: "S", value: 45, color: "#93B493" },
];

const maxValueDaily = 70;
const containerDaily = document.getElementById("barContainer-daily");
const yAxisDaily = document.getElementById("yAxisMarks-daily");

// Построение bar chart
weeklyData.forEach(item => {
  const group = document.createElement("div");
  group.className = "bar-group";

  const bar = document.createElement("div");
  bar.className = "bar-focus";

  const barMaxHeight = 160;
  bar.style.height = `${(item.value / maxValue) * barMaxHeight}px`;
  bar.style.backgroundColor = item.color;
  bar.title = `${item.value}`;

  const label = document.createElement("div");
  label.className = "day-label";
  label.textContent = item.day;

  group.appendChild(bar);
  group.appendChild(label);
  containerDaily.appendChild(group);
});
//mood
const bars = document.querySelectorAll(".bar-daily");

bars.forEach(bar => {
  const star = bar.querySelector(".star");
  const shape = bar.querySelector(".bar-shape-daily");

  star.addEventListener("click", () => {
    const isActive = shape.classList.contains("active");

    if (isActive) {
      // Сбросить этот бар
      star.src = "../photo/star.png"; // серый
      shape.classList.remove("active");
    } else {
      // Активировать этот бар
      star.src = "../photo/filledStar.png"; // золотой
      shape.classList.add("active");
    }
  });
});


//for all
const pieDataAll = {
  labels: ['Red', 'Blue', 'Yellow', 'Green'],
  datasets: [{
    data: [3, 2, 2, 1],
    backgroundColor: ['#F4A099', '#A3C1F3', '#FDE9A8', '#C9E2D0'],
    borderColor: 'black',
    borderWidth: 2
  }]
};

const barDataAll = {
  labels: ['', '', '', ''],
  datasets: [{
    label: '',
    data: [3, 2, 2, 1],
    backgroundColor: ['#F4A099', '#A3C1F3', '#FDE9A8', '#C9E2D0'],
    borderColor: 'black',
    borderWidth: 2
  }]
};

const ctxAll = document.getElementById('chartCanvas-all').getContext('2d');
let currentChartAll = new Chart(ctxAll, {
  type: 'pie',
  data: pieDataAll,
  options: {
    responsive: false,
    plugins: { legend: { display: false } }
  }
});

const toggleAll = document.getElementById('chartToggle-all');
toggleAll.addEventListener('click', () => {
  toggleAll.classList.toggle('active');
  currentChartAll.destroy();
  const type = toggleAll.classList.contains('active') ? 'bar' : 'pie';
  const data = toggleAll.classList.contains('active') ? barDataAll : pieDataAll;
  currentChartAll = new Chart(ctxAll, {
    type,
    data,
    options: {
      responsive: false,
      plugins: { legend: { display: false } },
      scales: type === 'bar' ? {
        x: {
          grid: { display: false },
          ticks: { display: false },
          title: { display: false }
        },
        y: {
          grid: { display: false },
          ticks: { display: false },
          title: { display: false }
        }
      } : {}
    }
  });
});

const dataAll = [
  { day: "M", value: 0, color: "#C9E2D0" },
  { day: "T", value: 60, color: "#CEB3FF" },
  { day: "W", value: 20, color: "#F4A099" },
  { day: "T", value: 3, color: "#FDE9A8" },
  { day: "F", value: 40, color: "#A3C1F3" },
  { day: "S", value: 48, color: "#FF8CE9" },
  { day: "S", value: 45, color: "#93B493" },
];

const maxValueAll = 70;
const containerAll = document.getElementById("barContainer-all");
const yAxisAll = document.getElementById("yAxisMarks-all");

dataAll.forEach(item => {
  const groupAll = document.createElement("div");
  groupAll.className = "bar-group";

  const barAll = document.createElement("div");
  barAll.className = "bar-focus";

  const barMaxHeight = 160;
  barAll.style.height = `${(item.value / maxValueAll) * barMaxHeight}px`;
  barAll.style.backgroundColor = item.color;

  const labelAll = document.createElement("div");
  labelAll.className = "day-label";
  labelAll.textContent = item.day;

  groupAll.appendChild(barAll);
  groupAll.appendChild(labelAll);
  containerAll.appendChild(groupAll);
});


//chat
const Block__Messages = document.getElementById('Block__Messages');
const Input = document.getElementById('Input');
const SendBtn = document.getElementById('send-btn');

SendBtn.addEventListener('click', () => {
    const value = Input.value.trim();
    if (value === '') return;


    const userMessage = `
            <div class="Message__Element User">
                <div class="Message">${value}</div>
                <img src="../photo/user.png" alt="" style="height: 50px; border-radius: 50%; border: 3px solid black; object-fit: cover; margin-left: 5px;">
            </div>
        `;
    Block__Messages.innerHTML += userMessage;

    Input.value = '';


    setTimeout(() => {
        const botMessage = `
                <div class="Message__Element Bot">
                    <img src="../photo/bunny.png" alt="" style="height: 50px;">
                    <div class="Message">...</div>
                </div>
            `;
        Block__Messages.innerHTML += botMessage;

        Block__Messages.scrollTop = Block__Messages.scrollHeight;

        const allMessages = Block__Messages.querySelectorAll('.Message__Element');
        if (allMessages.length > 30) {
            Block__Messages.removeChild(allMessages[0]);
        }

    }, 400);

    Block__Messages.scrollTop = Block__Messages.scrollHeight;
});
