//Sidebar
document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
    });




//reminder
const showBtn = document.getElementById("bunny");
const panel = document.getElementById("reminderPanel");

showBtn.addEventListener("click", () => {
  if (panel.style.display === "none") {
    panel.style.display = "block";
  } else {
    panel.style.display = "none";
  }
});
//create-poup
const backBtnCreate = document.querySelector('.back-btn');
const backBtnEdit = document.getElementById('backBtn');
const createPanel = document.getElementById('createPanel');
const editPanel = document.getElementById('editPanel');
const editBtn = document.getElementById('editBtn');
const addFolderBtn = document.getElementById('addFolder');
const createBtn = document.getElementById("createBtn");
const illustration = document.getElementById("illustration");
const folderBox = document.getElementById("folder-box");



backBtnCreate.addEventListener('click', () => {
  createPanel.style.display = 'none';
});

backBtnEdit.addEventListener('click', () => {
  editPanel.style.display = 'none';
  folderBox.style.opacity = "100%"; 
});

addFolderBtn.addEventListener('click', () => {
  createPanel.style.display = 'block';
});


//create folder
    
createBtn.addEventListener("click", function(){
  illustration.style.display = "none";
  folderBox.style.display = "flex";  
  createPanel.style.display = "none";  
});
// edit folder
editBtn.addEventListener("click", function(){
  folderBox.style.opacity = "60%";  
  editPanel.style.display = "block";  
});
