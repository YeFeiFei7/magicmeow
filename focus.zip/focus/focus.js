//Sidebar
document.addEventListener("DOMContentLoaded", function () {
    const sidebar = document.querySelector(".sidebar");
    const toggleBtn = document.querySelector(".toggle-btn");
    const addPlanButton = document.querySelector(".add-plan");
    const plusIcon = document.querySelector(".plus-icon");


    toggleBtn.addEventListener("click", function () {
        sidebar.classList.toggle("open");


        if (sidebar.classList.contains("open")) {
            plusIcon.style.display = "none";
        } else {
            plusIcon.style.display = "block";
        }
    });
    });




//Records-popup
    document.addEventListener("DOMContentLoaded", function () {
        const iconTrigger = document.querySelector(".icon-trigger"); // Иконка в main-content
        const recordsPopup = document.querySelector(".records-popup"); // Плашка "Focus Records"
        const backBtn = document.querySelector(".back-btn"); // Кнопка возврата в плашке
    
        //"Records Popup"
        iconTrigger.addEventListener("click", function () {
            recordsPopup.style.display = "flex"; 
        });
    
        // стрелку (Back)
        backBtn.addEventListener("click", function () {
            recordsPopup.style.display = "none"; 
        });
    });

//Focus-duration
document.addEventListener("DOMContentLoaded", function () {
    const addFocusBtn = document.querySelector(".add-focus-btn");
    const popupBox = document.getElementById("focusDurationPopup");
    const cancelBtn = popupBox.querySelector(".cancel-btn");
    const confirmBtn = document.getElementById("confirmBtn");
    const pauseBtn = document.getElementById("pauseBtn");
    const focusTitle = document.getElementById("focusTitle");
    const startBtn = document.getElementById("startBtn"); //
    const finCont = document.getElementById("fin-cont");
    const continueBtn = document.querySelector(".continue-btn");
    const showConfirm = document.getElementById("showConfirm");
    const confirmPopup = document.getElementById("confirmPopup");
    const cancelConfirm = document.getElementById("cancelConfirm");
    const confirmFinishBtn = document.getElementById("confirmFinishBtn");

    addFocusBtn.addEventListener("click", function () {
        popupBox.classList.add("active");
    });

    cancelBtn.addEventListener("click", function () {
        popupBox.classList.remove("active");
    });

    confirmBtn.addEventListener("click", function () {
        popupBox.classList.remove("active");
        focusTitle.textContent = "Reading...";
        pauseBtn.style.display = "block";
        addFocusBtn.style.display = "none";
        startBtn.style.display = "none";
    });

    pauseBtn.addEventListener("click", function () {
        pauseBtn.style.display = "none";
        finCont.style.display = "flex";
    });


    continueBtn.addEventListener("click", function () {
        finCont.style.display = "none";
        pauseBtn.style.display = "block";
    });

    showConfirm.addEventListener("click", function () {
        confirmPopup.style.display = "block";
    });

    cancelConfirm.addEventListener("click", function () {
        confirmPopup.style.display = "none";
        finCont.style.display = "none";
        pauseBtn.style.display = "block";
    });

    confirmFinishBtn.addEventListener("click", function () {
        confirmPopup.style.display = "none";
        focusTitle.textContent = "FOCUS TIME";
        pauseBtn.style.display = "none";
        addFocusBtn.style.display = "block";
        startBtn.style.display = "block";


        const mainContent = document.querySelector(".main-content");
        mainContent.style.transition = "margin-top 0.3s ease";
        mainContent.style.marginTop = "100px";
    });
});

//Start-btn
document.addEventListener("DOMContentLoaded", function () {
    const addFocusBtn = document.querySelector(".add-focus-btn");
    const popupBox = document.getElementById("focusDurationPopup");
    const pauseBtn = document.getElementById("pauseBtn");
    const focusTitle = document.getElementById("focusTitle");
    const startBtn = document.getElementById("startBtn");

    startBtn.addEventListener("click", function () {
        popupBox.classList.remove("active");
        focusTitle.textContent = "Reading...";
        pauseBtn.style.display = "block";
        addFocusBtn.style.display = "none";
        startBtn.style.display = "none";
    });
});
