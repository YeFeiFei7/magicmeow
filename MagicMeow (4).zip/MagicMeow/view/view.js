



// monthly(calendar)
const calendarDays = document.getElementById("calendarDays");
        const month = document.getElementById("month");
        const year = document.getElementById("year");
        const prevMonth = document.getElementById("prevMonth");
        const nextMonth = document.getElementById("nextMonth");

        let currentDate = new Date();

        function renderCalendar(date) {
            calendarDays.innerHTML = "";
            year.textContent = date.getFullYear();
            month.textContent = date.toLocaleDateString("en-US", { month: "long" });
            
            const firstDay = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
            const lastDate = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
            
            const offset = firstDay === 0 ? 6 : firstDay - 1;
            let row = document.createElement("tr");
            
            for (let i = 0; i < offset; i++) {
                row.appendChild(document.createElement("td"));
            }
            
            for (let day = 1; day <= lastDate; day++) {
                const cell = document.createElement("td");
                cell.textContent = day;
                
                if ((offset + day) % 7 === 0) {
                    row.appendChild(cell);
                    calendarDays.appendChild(row);
                    row = document.createElement("tr");
                } else {
                    row.appendChild(cell);
                }
            }
            
            if (row.children.length) {
                calendarDays.appendChild(row);
            }
        }

        prevMonth.addEventListener("click", () => {
            currentDate.setMonth(currentDate.getMonth() - 1);
            renderCalendar(currentDate);
        });

        nextMonth.addEventListener("click", () => {
            currentDate.setMonth(currentDate.getMonth() + 1);
            renderCalendar(currentDate);
        });

        renderCalendar(currentDate);