//folder
document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("toggle-btn");
    const closeBtn = document.getElementById("close-btn");
    const illustration = document.querySelector(".illustration");
    const folder = document.querySelector(".folder");

   
    toggleBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        folder.style.display = "block";
        closeBtn.style.display = "inline"; 
    });

    
    closeBtn.addEventListener("click", function () {
        folder.style.display = "none";
        illustration.style.display = "block";
        closeBtn.style.display = "none"; 
    });
});
//repeat
document.addEventListener("DOMContentLoaded", function () {
    const repeatBtn = document.getElementById("repeat-btn");
    const cancelBtn = document.getElementById("cancel-btn");
    const illustration = document.querySelector(".illustration");
    const repeat = document.querySelector(".selection-container");

   
    repeatBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        repeat.style.display = "block";
        cancelBtn.style.display = "inline"; 
    });

    
    cancelBtn.addEventListener("click", function () {
        repeat.style.display = "none";
        illustration.style.display = "block";
        cancelBtn.style.display = "none"; 
    });
});

//quadrants
document.addEventListener("DOMContentLoaded", function () {
    const quadrantsBtn = document.getElementById("quadrants-btn");
    const closeqBtn = document.getElementById("closeq-btn");
    const illustration = document.querySelector(".illustration");
    const quad = document.querySelector(".quadrants");

   
    quadrantsBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        quad.style.display = "flex";
        closeqBtn.style.display = "inline"; 
    });

    
    closeqBtn.addEventListener("click", function () {
        quad.style.display = "none";
        illustration.style.display = "block";
        closeqBtn.style.display = "none"; 
    });
});

//time
document.addEventListener("DOMContentLoaded", function () {
    const timeBtn = document.getElementById("time-btn");
    const closetBtn = document.getElementById("closet-btn");
    const illustration = document.querySelector(".illustration");
    const time = document.querySelector(".time-picker-container");

   
    timeBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        time.style.display = "block";
        closetBtn.style.display = "inline"; 
    });

    
    closetBtn.addEventListener("click", function () {
        time.style.display = "none";
        illustration.style.display = "block";
        closetBtn.style.display = "none"; 
    });
});

//reminder
document.addEventListener("DOMContentLoaded", function () {
    const reminderBtn = document.getElementById("reminder-btn");
    const closerBtn = document.getElementById("closer-btn");
    const illustration = document.querySelector(".illustration");
    const reminder = document.querySelector(".reminder");

   
    reminderBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        reminder.style.display = "block";
        closerBtn.style.display = "inline"; 
    });

    
    closerBtn.addEventListener("click", function () {
        reminder.style.display = "none";
        illustration.style.display = "block";
        closerBtn.style.display = "none"; 
    });
});

// date
document.addEventListener("DOMContentLoaded", function () {
    const dateBtn = document.getElementById("date-btn");
    const closedBtn = document.getElementById("closed-btn");
    const illustration = document.querySelector(".illustration");
    const date = document.querySelector(".calendar-container");

   
    dateBtn.addEventListener("click", function () {
        illustration.style.display = "none";
        date.style.display = "block";
        closedBtn.style.display = "inline"; 
    });

    
    closedBtn.addEventListener("click", function () {
        date.style.display = "none";
        illustration.style.display = "block";
        closedBtn.style.display = "none"; 
    });
});



let currentDate = dayjs();

function renderCalendar() {
    const firstDayOfMonth = currentDate.startOf('month');
    const lastDayOfMonth = currentDate.endOf('month');
    const firstDayWeekday = firstDayOfMonth.day() || 7;
    const daysInMonth = lastDayOfMonth.date();
    
    document.getElementById('month-year').textContent = currentDate.format('YYYY MMMM');
    
    let calendarBody = document.getElementById('calendar-body');
    calendarBody.innerHTML = '';
    
    let row = document.createElement('tr');
    let dayCounter = 1;
    
    for (let i = 1; i < firstDayWeekday; i++) {
        row.appendChild(document.createElement('td'));
    }
    
    for (let i = firstDayWeekday; dayCounter <= daysInMonth; i++) {
        let cell = document.createElement('td');
        cell.textContent = dayCounter;
        row.appendChild(cell);
        
        if (i % 7 === 0 || dayCounter === daysInMonth) {
            calendarBody.appendChild(row);
            row = document.createElement('tr');
        }
        dayCounter++;
    }
}

function changeMonth(offset) {
    currentDate = currentDate.add(offset, 'month');
    renderCalendar();
}

renderCalendar();